<?php
/*
Plugin name: Visitor Counter
Description: Daily Visitor Counter
Version: 0.1
Author: Rubel
Author URI: http://www.maxsoftbd.com
*/

function database_structure(){
	global $wpdb;
	$table_name = $wpdb->prefix."t_visitorcount";
	if($wpdb->get_var('SHOW TABLES LIKE'.$table_name) != $table_name){
		$sql ="CREATE TABLE $table_name (
		  `Id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		  `VisitorIP` varchar(50) NOT NULL,
		  `VisitorDate` Date NOT NULL,
		  `VisitCount` smallint(3) NOT NULL DEFAULT '0',
		  PRIMARY KEY (`Id`)
		) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
		require_once(ABSPATH.'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
}
register_activation_hook(__FILE__,"database_structure");

function count_visitor(){
	global $wpdb;
	$table_name = $wpdb->prefix."t_visitorcount";
	$visitor_ip = $_SERVER['REMOTE_ADDR'];
	$visitor_date = date('Y-m-d');
	$exist_visitor_curr_date = check_ip_exist($visitor_ip,$visitor_date);
	if(!$exist_visitor_curr_date){
		$sql ="insert into $table_name (`VisitorIP`,`VisitorDate`,`VisitCount`)values('$visitor_ip','$visitor_date',1);";	
		$wpdb -> get_results($sql);
	}
	//else
		//$sql ="update $table_name set `VisitCount`=`VisitCount`+1 where VisitorIP='$visitor_ip' and VisitorDate='$visitor_date';";	
	
}

function check_ip_exist($visitor_ip,$visitor_date){
    global $wpdb;
    $table_name = $wpdb->prefix . 't_visitorcount';
    $sql = "SELECT COUNT(*) FROM $table_name WHERE VisitorIP='$visitor_ip' AND VisitorDate='$visitor_date';";
    $count = $wpdb -> get_var($sql);   
    return $count;
}
add_action( 'init', 'count_visitor' );

function get_visitor_count($period='D'){
    global $wpdb;
    $table_name = $wpdb->prefix . 't_visitorcount';
	$condition = '';
    if($period == 'D'){
		$filter_date = date('Y-m-d');
		$condition = " WHERE `VisitorDate` = '$filter_date' ";
	}
    else if($period == 'Y'){
		$filter_date = date('Y-m-d', strtotime('-1 day'));
		$condition = " WHERE `VisitorDate` = '$filter_date' ";
	}
    else if($period == 'W'){
		$filter_date = date('Y-m-d', strtotime('-7 day'));
		$condition = " WHERE `VisitorDate` > '$filter_date' ";
	}
    else if($period == 'M'){
		$filter_date = date('Y-m-d', strtotime('-30 day'));
		$condition = " WHERE `VisitorDate` > '$filter_date' ";
	}
    else
		$condition = " ";
		
    $sql = "SELECT COUNT(*) FROM $table_name $condition;";
    $count = $wpdb -> get_var($sql);   
    return $count;
}

function get_visitor_details(){
	$html = "<aside class='visitordisplaybody' id='visitor-counter' style='font-family:Open Sans,sans-serif; color:#000000'>
	<h3>Visitors</h3>
	<div>
		<span>Today: ". get_visitor_count('D')."</span><br/>
		<span>Yesterday: " . get_visitor_count('Y')."</span><br/>
		<span>Last Week: " . get_visitor_count('W') ."</span><br/>
		<span>This Month: " . get_visitor_count('M')."</span><br/>
		<span>Total: " . get_visitor_count('T') ."</span>
	</ul>
	</div>
	</aside>";	
	return $html;
}

add_shortcode( 'visitordetails', 'get_visitor_details' );
?>